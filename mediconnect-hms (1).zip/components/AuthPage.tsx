
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { UserRole, Patient } from '../types';
import { ROUTE_PATHS } from '../constants';
import { Button, Input, Card, Spinner, Alert } from './common/UIPrimitives';
import { UserCircleIcon, LockClosedIcon, AcademicCapIcon } from './icons'; // Added AcademicCapIcon for visual flair

const AuthPage: React.FC = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const { login, register, isLoading: authLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (location.pathname === ROUTE_PATHS.REGISTER) {
      setIsLoginView(false);
    } else {
      setIsLoginView(true);
    }
  }, [location.pathname]);
  
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    if (!email || !password) {
      setError("Email and password are required.");
      return;
    }
    try {
      await login(email, password); // Removed role from login call
      // Navigation is handled by AuthContext
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials and try again.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccess(null);
    if (!name || !email || !password || !confirmPassword) {
      setError("All fields are required for registration.");
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    try {
      const patientData: Omit<Patient, 'id' | 'role' | 'medicalHistory'> = { name, email, password };
      await register(patientData);
      setSuccess('Registration successful! Please log in.');
      // Clear form and switch to login view
      setName(''); setEmail(''); setPassword(''); setConfirmPassword('');
      setIsLoginView(true);
      navigate(ROUTE_PATHS.LOGIN);
    } catch (err: any) {
      setError(err.message || 'Registration failed. Please try again.');
    }
  };

  const toggleView = () => {
    setIsLoginView(!isLoginView);
    setError(null);
    setSuccess(null);
    if (isLoginView) {
        navigate(ROUTE_PATHS.REGISTER);
    } else {
        navigate(ROUTE_PATHS.LOGIN);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-150px)] bg-gradient-to-br from-primary-light via-white to-secondary-light py-12 px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-10">
        <AcademicCapIcon className="w-16 h-16 text-primary mx-auto mb-3" /> 
        <h1 className="text-5xl font-extrabold text-primary">MediConnect HMS</h1>
        <p className="mt-2 text-lg text-gray-600">Your Health, Connected.</p>
      </div>

      <Card className="max-w-md w-full space-y-8 !shadow-2xl !bg-white/80 backdrop-blur-md">
        <div>
          <h2 className="text-center text-3xl font-bold text-gray-800">
            {isLoginView ? 'Sign in to your account' : 'Create Patient Account'}
          </h2>
        </div>

        {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
        {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}

        <form className="mt-8 space-y-6" onSubmit={isLoginView ? handleLogin : handleRegister}>
          {!isLoginView && (
            <Input
              id="name"
              label="Full Name"
              type="text"
              autoComplete="name"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your Name"
              icon={<UserCircleIcon className="h-5 w-5 text-gray-400" />}
            />
          )}
          <Input
            id="email-address"
            label="Email address"
            type="email"
            autoComplete="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Email address"
            icon={<UserCircleIcon className="h-5 w-5 text-gray-400" />}
          />
          <Input
            id="password"
            label="Password"
            type="password"
            autoComplete={isLoginView ? "current-password" : "new-password"}
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            icon={<LockClosedIcon className="h-5 w-5 text-gray-400" />}
          />
          {!isLoginView && (
            <Input
              id="confirm-password"
              label="Confirm Password"
              type="password"
              autoComplete="new-password"
              required
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm Password"
              icon={<LockClosedIcon className="h-5 w-5 text-gray-400" />}
            />
          )}

          {/* Role selection dropdown removed */}

          <div>
            <Button type="submit" className="w-full !py-3 !text-lg" disabled={authLoading} variant="primary">
              {authLoading ? <Spinner size="sm" className="mr-2" /> : null}
              {isLoginView ? 'Sign in' : 'Register'}
            </Button>
          </div>
        </form>

        <div className="text-sm text-center">
          <button onClick={toggleView} className="font-medium text-primary hover:text-primary-dark transition-colors">
            {isLoginView ? "Don't have an account? Register (Patient only)" : 'Already have an account? Sign in'}
          </button>
        </div>
      </Card>
    </div>
  );
};

export default AuthPage;
