
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { ROUTE_PATHS, ROLES } from '../../constants';
import { UserRole } from '../../types';
import { Button } from '../common/UIPrimitives';
import { ArrowLeftOnRectangleIcon, Bars3Icon, XMarkIcon, UserCircleIcon, CalendarDaysIcon, ClipboardDocumentListIcon, PencilSquareIcon, CogIcon, UsersIcon, AcademicCapIcon } from '../icons';

const Navbar: React.FC = () => {
  const { currentUser, currentRole, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    setMobileMenuOpen(false);
  };

  const commonLinks = [
    // { path: ROUTE_PATHS.HOME, label: 'Home', icon: <HomeIcon className="w-5 h-5"/> }
  ];

  const roleSpecificLinks: Record<UserRole, { path: string; label: string; icon: React.ReactNode }[]> = {
    [UserRole.PATIENT]: [
      { path: ROUTE_PATHS.PATIENT_DASHBOARD, label: 'Dashboard', icon: <UserCircleIcon className="w-5 h-5"/> },
      // Sub-links are handled within dashboard
    ],
    [UserRole.DOCTOR]: [
      { path: ROUTE_PATHS.DOCTOR_DASHBOARD, label: 'Dashboard', icon: <AcademicCapIcon className="w-5 h-5"/> },
    ],
    [UserRole.ADMIN]: [
      { path: ROUTE_PATHS.ADMIN_DASHBOARD, label: 'Dashboard', icon: <CogIcon className="w-5 h-5"/> },
    ],
  };

  const navLinks = currentUser && currentRole ? [...commonLinks, ...roleSpecificLinks[currentRole]] : commonLinks;

  return (
    <nav className="bg-primary shadow-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link to={currentUser ? navLinks[0]?.path || ROUTE_PATHS.HOME : ROUTE_PATHS.HOME} className="flex-shrink-0 text-white text-2xl font-bold">
              MediConnect
            </Link>
          </div>
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navLinks.map((link) => (
                <Link
                  key={link.label}
                  to={link.path}
                  className="text-primary-light hover:bg-primary-dark hover:text-white px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  {link.icon && <span className="mr-2">{link.icon}</span>}
                  {link.label}
                </Link>
              ))}
              {currentUser && (
                <Button variant="ghost" size="sm" onClick={handleLogout} className="text-primary-light hover:bg-primary-dark hover:text-white ml-4">
                  <ArrowLeftOnRectangleIcon className="w-5 h-5 mr-2" /> Logout
                </Button>
              )}
            </div>
          </div>
          <div className="flex items-center md:hidden">
            {currentUser && <span className="text-white mr-3 text-sm">{currentUser.name} ({ROLES[currentRole!]})</span>}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-primary-light hover:text-white hover:bg-primary-dark focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              aria-controls="mobile-menu"
              aria-expanded={mobileMenuOpen}
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? <XMarkIcon className="block h-6 w-6" /> : <Bars3Icon className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden" id="mobile-menu">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className="text-primary-light hover:bg-primary-dark hover:text-white block px-3 py-2 rounded-md text-base font-medium flex items-center"
              >
                {link.icon && <span className="mr-2">{link.icon}</span>}
                {link.label}
              </Link>
            ))}
            {currentUser && (
              <Button variant="ghost" size="sm" onClick={handleLogout} className="text-primary-light hover:bg-primary-dark hover:text-white w-full mt-2 text-left px-3 py-2">
                 <ArrowLeftOnRectangleIcon className="w-5 h-5 mr-2" /> Logout
              </Button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
