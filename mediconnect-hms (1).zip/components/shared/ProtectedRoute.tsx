
import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { UserRole } from '../../types';
import { ROUTE_PATHS } from '../../constants';
import { Spinner } from '../common/UIPrimitives';

interface ProtectedRouteProps {
  allowedRoles: UserRole[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ allowedRoles }) => {
  const { currentUser, currentRole, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!currentUser || !currentRole) {
    return <Navigate to={ROUTE_PATHS.LOGIN} replace />;
  }

  if (!allowedRoles.includes(currentRole)) {
    // Redirect to a generic unauthorized page or their respective dashboard if that's more appropriate
    // For simplicity, redirecting to login or a generic home which might redirect again.
    // A better approach might be a dedicated "/unauthorized" page.
    alert("You do not have permission to access this page.");
    // Redirect to their default dashboard or login
    if (currentRole === UserRole.PATIENT) return <Navigate to={ROUTE_PATHS.PATIENT_DASHBOARD} replace />;
    if (currentRole === UserRole.DOCTOR) return <Navigate to={ROUTE_PATHS.DOCTOR_DASHBOARD} replace />;
    if (currentRole === UserRole.ADMIN) return <Navigate to={ROUTE_PATHS.ADMIN_DASHBOARD} replace />;
    return <Navigate to={ROUTE_PATHS.LOGIN} replace />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
