
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import * as apiService from '../../services/apiService';
import { Appointment, Doctor, AvailabilitySlot, MedicalRecord } from '../../types';
import { Button, Input, Card, Modal, Spinner, Select, Textarea, Alert } from '../common/UIPrimitives';
import { CalendarDaysIcon, ClipboardDocumentListIcon, PlusCircleIcon, PencilSquareIcon, TrashIcon, EyeIcon } from '../icons';

type DoctorDashboardTab = 'appointments' | 'schedule' | 'patients'; // Patients could show list of unique patients seen

const DoctorDashboard: React.FC = () => {
  const { currentUser, updateUserProfile, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<DoctorDashboardTab>('appointments');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [availability, setAvailability] = useState<AvailabilitySlot[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [isSlotModalOpen, setIsSlotModalOpen] = useState(false);
  const [currentSlot, setCurrentSlot] = useState<Partial<AvailabilitySlot>>({ dayOfWeek: 'Monday', startTime: '09:00', endTime: '17:00' });
  
  const [isRecordModalOpen, setIsRecordModalOpen] = useState(false);
  const [currentAppointmentForRecord, setCurrentAppointmentForRecord] = useState<Appointment | null>(null);
  const [medicalRecordData, setMedicalRecordData] = useState<Omit<MedicalRecord, 'id'>>({ appointmentId: '', date: '', notes: '', diagnosis: '', prescription: '' });
  
  const doctor = currentUser as Doctor;

  const fetchData = useCallback(async () => {
    if (!doctor) return;
    setIsLoading(true);
    setError(null);
    try {
      const [apts, avl] = await Promise.all([
        apiService.getDoctorAppointments(doctor.id),
        apiService.getDoctorAvailability(doctor.id),
      ]);
      setAppointments(apts);
      setAvailability(avl || []); // Ensure availability is an array
    } catch (err) {
      setError('Failed to load data. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [doctor]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAvailabilityUpdate = async () => {
    if (!doctor) return;
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      await apiService.updateDoctorAvailability(doctor.id, availability);
      setSuccess('Availability updated successfully!');
    } catch (err) {
      setError('Failed to update availability.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const addAvailabilitySlot = () => {
    if (currentSlot.dayOfWeek && currentSlot.startTime && currentSlot.endTime) {
       // Prevent duplicate days
      if (availability.find(slot => slot.dayOfWeek === currentSlot.dayOfWeek)) {
        setError(`Availability for ${currentSlot.dayOfWeek} already exists. Edit it instead.`);
        return;
      }
      setAvailability([...availability, currentSlot as AvailabilitySlot]);
      setCurrentSlot({ dayOfWeek: 'Monday', startTime: '09:00', endTime: '17:00' }); // Reset
      setIsSlotModalOpen(false);
      setSuccess('Slot added. Remember to save all changes.');
    } else {
        setError('All fields for the slot are required.');
    }
  };

  const removeAvailabilitySlot = (day: string) => {
    setAvailability(availability.filter(slot => slot.dayOfWeek !== day));
    setSuccess('Slot removed. Remember to save all changes.');
  };

  const openRecordModal = (appointment: Appointment) => {
    setCurrentAppointmentForRecord(appointment);
    setMedicalRecordData({
      appointmentId: appointment.id,
      date: new Date().toISOString().split('T')[0], // Default to today
      notes: '',
      diagnosis: '',
      prescription: '',
    });
    setIsRecordModalOpen(true);
  };

  const handleAddMedicalRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentAppointmentForRecord) return;
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      await apiService.addMedicalRecord(medicalRecordData);
      setSuccess('Medical record added successfully.');
      setIsRecordModalOpen(false);
      fetchData(); // Refresh appointments, status might change to 'completed'
    } catch (err: any) {
      setError(err.message || 'Failed to add medical record.');
    } finally {
      setIsLoading(false);
    }
  };

  const dayOfWeekOptions = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map(day => ({ value: day, label: day }));
  const timeOptions = Array.from({ length: 24 * 2 }, (_, i) => {
    const hours = String(Math.floor(i / 2)).padStart(2, '0');
    const minutes = String((i % 2) * 30).padStart(2, '0');
    return { value: `${hours}:${minutes}`, label: `${hours}:${minutes}` };
  });

  const renderTabContent = () => {
    switch (activeTab) {
      case 'appointments':
        return (
          <Card title="My Appointments">
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            {appointments.length === 0 && !isLoading && <p className="text-gray-600">You have no appointments scheduled.</p>}
            <ul className="space-y-4">
              {appointments.map(apt => (
                <li key={apt.id} className="p-4 border rounded-lg shadow-sm bg-gray-50 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg font-semibold text-primary">{apt.patientName}</p>
                      <p className="text-gray-700">Date: {new Date(apt.date + 'T' + apt.time).toLocaleDateString()} at {apt.time}</p>
                      <p className="text-gray-600 text-sm">Reason: {apt.reason}</p>
                    </div>
                     <div className="text-right">
                         <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                            apt.status === 'booked' ? 'bg-blue-100 text-blue-700' :
                            apt.status === 'completed' ? 'bg-green-100 text-green-700' :
                            'bg-red-100 text-red-700'}`}>
                            {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                        </span>
                        {apt.status === 'booked' && (
                            <Button size="sm" onClick={() => openRecordModal(apt)} className="mt-2 ml-2" leftIcon={<PencilSquareIcon className="w-4 h-4"/>}>
                                Add Record
                            </Button>
                        )}
                         {apt.status === 'completed' && (
                            <Button variant="ghost" size="sm" onClick={() => openRecordModal(apt)} className="mt-2 ml-2" leftIcon={<EyeIcon className="w-4 h-4"/>}>
                                View/Edit Record
                            </Button>
                        )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Card>
        );
      case 'schedule':
        return (
          <Card title="Manage My Availability" actions={
            <div className="space-x-2">
                <Button onClick={() => setIsSlotModalOpen(true)} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>Add Slot</Button>
                <Button onClick={handleAvailabilityUpdate} variant="primary" disabled={isLoading}>
                    {isLoading ? <Spinner size="sm"/> : 'Save Changes'}
                </Button>
            </div>
          }>
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            {availability.length === 0 && <p className="text-gray-600">You have not set any availability yet.</p>}
            <ul className="space-y-3">
              {availability.sort((a,b) => dayOfWeekOptions.findIndex(d => d.value === a.dayOfWeek) - dayOfWeekOptions.findIndex(d => d.value === b.dayOfWeek)).map(slot => (
                <li key={slot.dayOfWeek} className="p-3 border rounded-md flex justify-between items-center bg-gray-50">
                  <div>
                    <span className="font-medium text-gray-800">{slot.dayOfWeek}: </span>
                    <span className="text-gray-600">{slot.startTime} - {slot.endTime}</span>
                  </div>
                  <Button variant="danger" size="sm" onClick={() => removeAvailabilitySlot(slot.dayOfWeek)} leftIcon={<TrashIcon className="w-4 h-4"/>}>Remove</Button>
                </li>
              ))}
            </ul>
          </Card>
        );
      default:
        return null;
    }
  };
  
  if (!doctor) {
    return (
      <div className="flex justify-center items-center h-full">
        <Spinner size="lg" /><p className="ml-4">Loading doctor data...</p>
      </div>
    );
  }

  const TABS = [
    { id: 'appointments' as DoctorDashboardTab, label: 'Appointments', icon: <CalendarDaysIcon className="w-5 h-5 mr-2" /> },
    { id: 'schedule' as DoctorDashboardTab, label: 'Manage Schedule', icon: <ClipboardDocumentListIcon className="w-5 h-5 mr-2" /> },
  ];

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Dr. {doctor.name}'s Dashboard <span className="text-lg text-gray-600">({doctor.specialization})</span></h1>
      
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {setActiveTab(tab.id); setError(null); setSuccess(null);}}
                className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                  ${activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>

      {renderTabContent()}

      <Modal isOpen={isSlotModalOpen} onClose={() => setIsSlotModalOpen(false)} title="Add New Availability Slot">
        <div className="space-y-4">
          <Select label="Day of Week" options={dayOfWeekOptions} value={currentSlot.dayOfWeek || ''} onChange={e => setCurrentSlot({ ...currentSlot, dayOfWeek: e.target.value as AvailabilitySlot['dayOfWeek'] })} />
          <Select label="Start Time" options={timeOptions} value={currentSlot.startTime || ''} onChange={e => setCurrentSlot({ ...currentSlot, startTime: e.target.value })} />
          <Select label="End Time" options={timeOptions} value={currentSlot.endTime || ''} onChange={e => setCurrentSlot({ ...currentSlot, endTime: e.target.value })} />
        </div>
        <div className="mt-6 flex justify-end space-x-2">
            <Button variant="ghost" onClick={() => setIsSlotModalOpen(false)}>Cancel</Button>
            <Button onClick={addAvailabilitySlot}>Add Slot</Button>
        </div>
      </Modal>

      <Modal isOpen={isRecordModalOpen} onClose={() => setIsRecordModalOpen(false)} title={`Medical Record for ${currentAppointmentForRecord?.patientName}`} size="lg">
        {currentAppointmentForRecord && (
          <form onSubmit={handleAddMedicalRecord} className="space-y-4">
            <p><strong>Appointment:</strong> {new Date(currentAppointmentForRecord.date).toLocaleDateString()} at {currentAppointmentForRecord.time}</p>
            <p><strong>Reason:</strong> {currentAppointmentForRecord.reason}</p>
            <Input label="Record Date" type="date" value={medicalRecordData.date} onChange={e => setMedicalRecordData({...medicalRecordData, date: e.target.value})} required/>
            <Textarea label="Notes" value={medicalRecordData.notes} onChange={e => setMedicalRecordData({...medicalRecordData, notes: e.target.value})} required rows={4}/>
            <Input label="Diagnosis (optional)" value={medicalRecordData.diagnosis || ''} onChange={e => setMedicalRecordData({...medicalRecordData, diagnosis: e.target.value})} />
            <Textarea label="Prescription (optional)" value={medicalRecordData.prescription || ''} onChange={e => setMedicalRecordData({...medicalRecordData, prescription: e.target.value})} rows={2}/>
            <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="ghost" onClick={() => setIsRecordModalOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={isLoading}>
                    {isLoading ? <Spinner size="sm"/> : 'Save Record'}
                </Button>
            </div>
          </form>
        )}
      </Modal>
    </div>
  );
};

export default DoctorDashboard;
