
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import * as apiService from '../../services/apiService';
import { Appointment, Doctor, Patient, UserRole } from '../../types';
import { Button, Input, Card, Modal, Spinner, Select, Alert } from '../common/UIPrimitives';
import { UsersIcon, CalendarDaysIcon, PlusCircleIcon, PencilSquareIcon, TrashIcon, EyeIcon, AcademicCapIcon, ClipboardDocumentListIcon } from '../icons';

type AdminDashboardTab = 'manageDoctors' | 'allAppointments' | 'doctorSchedules' | 'allPatients';

const AdminDashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<AdminDashboardTab>('manageDoctors');
  
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [allAppointments, setAllAppointments] = useState<Appointment[]>([]);
  const [allPatients, setAllPatients] = useState<Patient[]>([]);
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [isDoctorModalOpen, setIsDoctorModalOpen] = useState(false);
  const [currentDoctor, setCurrentDoctor] = useState<Partial<Doctor> & { password?: string }>({});
  const [isEditMode, setIsEditMode] = useState(false);

  const [viewDoctorSchedules, setViewDoctorSchedules] = useState<Doctor | null>(null);

  const admin = currentUser as Doctor; // Type assertion for admin user (though properties are generic User)

  const fetchData = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [docs, apts, pats] = await Promise.all([
        apiService.getAllDoctors(),
        apiService.getAllAppointments(),
        apiService.getAllPatients(),
      ]);
      setDoctors(docs);
      setAllAppointments(apts);
      setAllPatients(pats);
    } catch (err) {
      setError('Failed to load data. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const openDoctorModal = (doctor?: Doctor) => {
    setIsEditMode(!!doctor);
    setCurrentDoctor(doctor ? { ...doctor } : { role: UserRole.DOCTOR });
    setIsDoctorModalOpen(true);
    setError(null);
    setSuccess(null);
  };

  const handleDoctorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentDoctor.name || !currentDoctor.email || !currentDoctor.specialization || (!isEditMode && !currentDoctor.password)) {
        setError("Name, email, specialization, and password (for new doctors) are required.");
        return;
    }
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      if (isEditMode && currentDoctor.id) {
        const { password, ...updateData } = currentDoctor; // Don't send password on update unless it's a feature
        await apiService.updateDoctor(currentDoctor.id, updateData);
        setSuccess('Doctor updated successfully!');
      } else {
        const { id, ...newDoctorData } = currentDoctor;
        await apiService.addDoctor(newDoctorData as Omit<Doctor, 'id' | 'role' | 'availability'>); // Ensure type match
        setSuccess('Doctor added successfully!');
      }
      setIsDoctorModalOpen(false);
      fetchData(); // Refresh doctor list
    } catch (err: any) {
      setError(err.message || `Failed to ${isEditMode ? 'update' : 'add'} doctor.`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteDoctor = async (doctorId: string) => {
    if (!window.confirm("Are you sure you want to delete this doctor? This action cannot be undone and may affect associated appointments.")) return;
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      await apiService.deleteDoctor(doctorId);
      setSuccess('Doctor deleted successfully!');
      fetchData(); // Refresh doctor list
    } catch (err: any) {
      setError(err.message || 'Failed to delete doctor.');
    } finally {
      setIsLoading(false);
    }
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'manageDoctors':
        return (
          <Card title="Manage Doctors" actions={<Button onClick={() => openDoctorModal()} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>Add Doctor</Button>}>
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Specialization</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {doctors.map(doc => (
                    <tr key={doc.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{doc.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{doc.specialization}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{doc.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{doc.phone || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => openDoctorModal(doc)} leftIcon={<PencilSquareIcon className="w-4 h-4"/>}>Edit</Button>
                        <Button variant="danger" size="sm" onClick={() => handleDeleteDoctor(doc.id)} leftIcon={<TrashIcon className="w-4 h-4"/>}>Delete</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {doctors.length === 0 && !isLoading && <p className="text-center text-gray-500 py-4">No doctors found.</p>}
          </Card>
        );
      case 'allAppointments':
        return (
          <Card title="All Patient Appointments">
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Patient</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Doctor</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Reason</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                    {allAppointments.map(apt => (
                        <tr key={apt.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{apt.patientName}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{apt.doctorName}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(apt.date + 'T' + apt.time).toLocaleString()}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 truncate max-w-xs">{apt.reason}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                            <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                apt.status === 'booked' ? 'bg-blue-100 text-blue-800' :
                                apt.status === 'completed' ? 'bg-green-100 text-green-800' :
                                'bg-red-100 text-red-800'}`}>
                                {apt.status}
                            </span>
                        </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
            </div>
            {allAppointments.length === 0 && !isLoading && <p className="text-center text-gray-500 py-4">No appointments found.</p>}
          </Card>
        );
      case 'doctorSchedules':
         const selectedDoctorForSchedule = doctors.find(d => d.id === viewDoctorSchedules?.id);
        return (
          <Card title="View Doctor Schedules">
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            <div className="mb-4">
              <Select
                label="Select Doctor to View Schedule"
                options={[{value: '', label: 'Select a doctor'}, ...doctors.map(doc => ({ value: doc.id, label: doc.name }))]}
                onChange={e => setViewDoctorSchedules(doctors.find(d => d.id === e.target.value) || null)}
                value={viewDoctorSchedules?.id || ''}
              />
            </div>
            {selectedDoctorForSchedule && (
              <div>
                <h3 className="text-xl font-semibold mb-2">Schedule for Dr. {selectedDoctorForSchedule.name}</h3>
                {selectedDoctorForSchedule.availability && selectedDoctorForSchedule.availability.length > 0 ? (
                  <ul className="space-y-2">
                    {selectedDoctorForSchedule.availability.map(slot => (
                      <li key={slot.dayOfWeek} className="p-3 bg-gray-100 rounded-md">
                        <span className="font-medium">{slot.dayOfWeek}:</span> {slot.startTime} - {slot.endTime}
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p>No availability set for Dr. {selectedDoctorForSchedule.name}.</p>
                )}
              </div>
            )}
             {!selectedDoctorForSchedule && !isLoading && <p className="text-gray-500">Please select a doctor to view their schedule.</p>}
          </Card>
        );
      case 'allPatients':
        return (
          <Card title="All Registered Patients">
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DOB</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {allPatients.map(pat => (
                    <tr key={pat.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{pat.name}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{pat.email}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{pat.phone || 'N/A'}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{pat.dob ? new Date(pat.dob).toLocaleDateString() : 'N/A'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {allPatients.length === 0 && !isLoading && <p className="text-center text-gray-500 py-4">No patients found.</p>}
          </Card>
        );
      default:
        return null;
    }
  };

  if (!admin) {
    return (
      <div className="flex justify-center items-center h-full">
        <Spinner size="lg" /><p className="ml-4">Loading admin data...</p>
      </div>
    );
  }

  const TABS = [
    { id: 'manageDoctors' as AdminDashboardTab, label: 'Manage Doctors', icon: <AcademicCapIcon className="w-5 h-5 mr-2" /> },
    { id: 'allAppointments' as AdminDashboardTab, label: 'All Appointments', icon: <CalendarDaysIcon className="w-5 h-5 mr-2" /> },
    { id: 'doctorSchedules' as AdminDashboardTab, label: 'Doctor Schedules', icon: <ClipboardDocumentListIcon className="w-5 h-5 mr-2" /> },
    { id: 'allPatients' as AdminDashboardTab, label: 'View Patients', icon: <UsersIcon className="w-5 h-5 mr-2" /> },
  ];

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Admin Dashboard</h1>
       <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => {setActiveTab(tab.id); setError(null); setSuccess(null);}}
                className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                  ${activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </div>
      
      {renderTabContent()}

      <Modal isOpen={isDoctorModalOpen} onClose={() => setIsDoctorModalOpen(false)} title={isEditMode ? 'Edit Doctor' : 'Add New Doctor'} size="lg">
        <form onSubmit={handleDoctorSubmit} className="space-y-4">
          <Input label="Full Name" value={currentDoctor.name || ''} onChange={e => setCurrentDoctor({ ...currentDoctor, name: e.target.value })} required />
          <Input label="Email" type="email" value={currentDoctor.email || ''} onChange={e => setCurrentDoctor({ ...currentDoctor, email: e.target.value })} required />
          {!isEditMode && <Input label="Password" type="password" value={currentDoctor.password || ''} onChange={e => setCurrentDoctor({ ...currentDoctor, password: e.target.value })} required />}
          <Input label="Specialization" value={currentDoctor.specialization || ''} onChange={e => setCurrentDoctor({ ...currentDoctor, specialization: e.target.value })} required />
          <Input label="Phone (Optional)" type="tel" value={currentDoctor.phone || ''} onChange={e => setCurrentDoctor({ ...currentDoctor, phone: e.target.value })} />
           {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
          <div className="flex justify-end space-x-3 pt-4">
            <Button type="button" variant="ghost" onClick={() => setIsDoctorModalOpen(false)}>Cancel</Button>
            <Button type="submit" disabled={isLoading}>
                {isLoading ? <Spinner size="sm"/> : (isEditMode ? 'Save Changes' : 'Add Doctor')}
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AdminDashboard;

