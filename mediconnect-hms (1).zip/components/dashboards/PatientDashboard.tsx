
import React, { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import * as apiService from '../../services/apiService';
import { Appointment, Doctor, MedicalRecord, Patient } from '../../types';
import { Button, Input, Card, Modal, Spinner, Select, Textarea, Alert } from '../common/UIPrimitives';
import { CalendarDaysIcon, ClipboardDocumentListIcon, PencilSquareIcon, PlusCircleIcon, TrashIcon } from '../icons';

type PatientDashboardTab = 'appointments' | 'history' | 'profile' | 'book';

const PatientDashboard: React.FC = () => {
  const { currentUser, updateUserProfile, isLoading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<PatientDashboardTab>('appointments');
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [medicalHistory, setMedicalHistory] = useState<MedicalRecord[]>([]);
  const [profileData, setProfileData] = useState<Partial<Patient>>({});
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [bookingDetails, setBookingDetails] = useState({ doctorId: '', date: '', time: '', reason: '' });
  
  const patient = currentUser as Patient;

  const fetchData = useCallback(async () => {
    if (!patient) return;
    setIsLoading(true);
    setError(null);
    try {
      const [apts, historyRecs, allDocs] = await Promise.all([
        apiService.getPatientAppointments(patient.id),
        apiService.getPatientMedicalRecords(patient.id),
        apiService.getAllDoctors() // For booking
      ]);
      setAppointments(apts);
      setMedicalHistory(historyRecs);
      setDoctors(allDocs);
      setProfileData({ name: patient.name, email: patient.email, dob: patient.dob, phone: patient.phone, address: patient.address });
    } catch (err) {
      setError('Failed to load data. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patient?.id, patient?.name, patient?.email, patient?.dob, patient?.phone, patient?.address]); // dependencies ensure profileData is updated if currentUser changes

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleProfileUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patient) return;
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      await updateUserProfile(profileData);
      setSuccess('Profile updated successfully!');
    } catch (err) {
      setError('Failed to update profile.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patient || !bookingDetails.doctorId || !bookingDetails.date || !bookingDetails.time || !bookingDetails.reason) {
      setError("All fields are required for booking.");
      return;
    }
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
      await apiService.bookAppointment({
        patientId: patient.id,
        doctorId: bookingDetails.doctorId,
        date: bookingDetails.date,
        time: bookingDetails.time,
        reason: bookingDetails.reason,
      });
      setSuccess('Appointment booked successfully!');
      setIsBookingModalOpen(false);
      setBookingDetails({ doctorId: '', date: '', time: '', reason: '' });
      fetchData(); // Refresh appointments
    } catch (err: any) {
      setError(err.message || 'Failed to book appointment.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelAppointment = async (appointmentId: string) => {
    if (!window.confirm("Are you sure you want to cancel this appointment?")) return;
    setError(null);
    setSuccess(null);
    setIsLoading(true);
    try {
        await apiService.cancelAppointment(appointmentId);
        setSuccess('Appointment cancelled successfully!');
        fetchData(); // Refresh appointments
    } catch (err: any) {
        setError(err.message || 'Failed to cancel appointment.');
        console.error(err);
    } finally {
        setIsLoading(false);
    }
  };


  const availableTimeSlots = (doctorId: string, date: string): {value: string, label: string}[] => {
    const doctor = doctors.find(d => d.id === doctorId);
    if (!doctor || !doctor.availability || !date) return [];
    
    const dayOfWeek = new Date(date).toLocaleDateString('en-US', { weekday: 'long' });
    const dayAvailability = doctor.availability.find(slot => slot.dayOfWeek === dayOfWeek);
    if (!dayAvailability) return [];

    const slots = [];
    let currentTime = new Date(`${date}T${dayAvailability.startTime}`);
    const endTime = new Date(`${date}T${dayAvailability.endTime}`);

    while(currentTime < endTime) {
        // Check if this slot is already booked for this doctor on this date
        const isBooked = appointments.some(apt => 
            apt.doctorId === doctorId && 
            apt.date === date && 
            apt.time === currentTime.toTimeString().substring(0,5) &&
            apt.status === 'booked'
        );

        if(!isBooked) {
             slots.push({ value: currentTime.toTimeString().substring(0,5), label: currentTime.toTimeString().substring(0,5) });
        }
        currentTime.setMinutes(currentTime.getMinutes() + 30); // 30 min slots
    }
    return slots;
  };
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'appointments':
        return (
          <Card title="My Appointments" actions={<Button onClick={() => setActiveTab('book')} leftIcon={<PlusCircleIcon className="w-5 h-5"/>}>Book New</Button>}>
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            {appointments.length === 0 && !isLoading && <p className="text-gray-600">You have no upcoming appointments.</p>}
            <ul className="space-y-4">
              {appointments.map(apt => (
                <li key={apt.id} className="p-4 border rounded-lg shadow-sm bg-gray-50 hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-lg font-semibold text-primary">{apt.doctorName} <span className="text-sm text-gray-500">({(doctors.find(d=>d.id===apt.doctorId))?.specialization})</span></p>
                      <p className="text-gray-700">Date: {new Date(apt.date + 'T' + apt.time).toLocaleDateString()} at {apt.time}</p>
                      <p className="text-gray-600 text-sm">Reason: {apt.reason}</p>
                    </div>
                    <div className="text-right">
                         <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                            apt.status === 'booked' ? 'bg-blue-100 text-blue-700' :
                            apt.status === 'completed' ? 'bg-green-100 text-green-700' :
                            'bg-red-100 text-red-700'}`}>
                            {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                        </span>
                        {apt.status === 'booked' && (
                             <Button variant="danger" size="sm" onClick={() => handleCancelAppointment(apt.id)} className="mt-2 ml-2" leftIcon={<TrashIcon className="w-4 h-4"/>}>Cancel</Button>
                        )}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </Card>
        );
      case 'book':
        return (
          <Card title="Book a New Appointment">
             {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
            {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            <form onSubmit={handleBookingSubmit} className="space-y-4">
              <Select
                label="Select Doctor"
                options={doctors.map(doc => ({ value: doc.id, label: `${doc.name} (${doc.specialization})` }))}
                value={bookingDetails.doctorId}
                onChange={(e) => setBookingDetails({ ...bookingDetails, doctorId: e.target.value, time: '' })} // Reset time on doctor change
                required
              />
              <Input
                label="Date"
                type="date"
                value={bookingDetails.date}
                onChange={(e) => setBookingDetails({ ...bookingDetails, date: e.target.value, time: '' })} // Reset time on date change
                min={new Date().toISOString().split('T')[0]} // Today onwards
                required
              />
              {bookingDetails.doctorId && bookingDetails.date && (
                <Select
                  label="Available Time"
                  options={availableTimeSlots(bookingDetails.doctorId, bookingDetails.date)}
                  value={bookingDetails.time}
                  onChange={(e) => setBookingDetails({ ...bookingDetails, time: e.target.value })}
                  required
                  disabled={availableTimeSlots(bookingDetails.doctorId, bookingDetails.date).length === 0}
                />
              )}
              {availableTimeSlots(bookingDetails.doctorId, bookingDetails.date).length === 0 && bookingDetails.doctorId && bookingDetails.date &&
                <p className="text-sm text-yellow-600">No available slots for selected doctor/date. Please try another combination.</p>
              }
              <Textarea
                label="Reason for Appointment"
                value={bookingDetails.reason}
                onChange={(e) => setBookingDetails({ ...bookingDetails, reason: e.target.value })}
                required
                placeholder="Briefly describe the reason for your visit"
              />
              <div className="flex justify-end space-x-2">
                 <Button type="button" variant="ghost" onClick={() => setActiveTab('appointments')}>Cancel</Button>
                 <Button 
                    type="submit" 
                    disabled={isLoading || (availableTimeSlots(bookingDetails.doctorId, bookingDetails.date).length === 0 && !!bookingDetails.doctorId && !!bookingDetails.date)}
                  >
                    {isLoading ? <Spinner size="sm"/> : 'Book Appointment'}
                 </Button>
              </div>
            </form>
          </Card>
        );
      case 'history':
        return (
          <Card title="My Medical History">
            {isLoading && <div className="flex justify-center p-4"><Spinner /></div>}
             {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
            {medicalHistory.length === 0 && !isLoading && <p className="text-gray-600">You have no medical records available.</p>}
            <ul className="space-y-4">
              {medicalHistory.map(rec => (
                <li key={rec.id} className="p-4 border rounded-lg shadow-sm bg-gray-50">
                  <p className="text-lg font-semibold text-primary">Record Date: {new Date(rec.date).toLocaleDateString()}</p>
                  <p className="text-gray-700"><span className="font-medium">Appointment ID:</span> {rec.appointmentId} (with {appointments.find(a=>a.id === rec.appointmentId)?.doctorName})</p>
                  {rec.diagnosis && <p className="text-gray-700"><span className="font-medium">Diagnosis:</span> {rec.diagnosis}</p>}
                  <p className="text-gray-600 mt-1"><span className="font-medium">Notes:</span> {rec.notes}</p>
                  {rec.prescription && <p className="text-gray-600 mt-1"><span className="font-medium">Prescription:</span> {rec.prescription}</p>}
                </li>
              ))}
            </ul>
          </Card>
        );
      case 'profile':
        return (
          <Card title="Edit My Profile">
             {(isLoading || authLoading) && <div className="flex justify-center p-4"><Spinner /></div>}
             {error && <Alert type="error" message={error} onClose={() => setError(null)} />}
             {success && <Alert type="success" message={success} onClose={() => setSuccess(null)} />}
            <form onSubmit={handleProfileUpdate} className="space-y-4">
              <Input label="Full Name" value={profileData.name || ''} onChange={e => setProfileData({ ...profileData, name: e.target.value })} required />
              <Input label="Email" type="email" value={profileData.email || ''} onChange={e => setProfileData({ ...profileData, email: e.target.value })} required disabled /> {/* Email usually not editable */}
              <Input label="Date of Birth" type="date" value={profileData.dob || ''} onChange={e => setProfileData({ ...profileData, dob: e.target.value })} />
              <Input label="Phone Number" type="tel" value={profileData.phone || ''} onChange={e => setProfileData({ ...profileData, phone: e.target.value })} />
              <Textarea label="Address" value={profileData.address || ''} onChange={e => setProfileData({ ...profileData, address: e.target.value })} />
              <div className="flex justify-end">
                <Button type="submit" disabled={isLoading || authLoading}>
                  {(isLoading || authLoading) ? <Spinner size="sm"/> : 'Save Changes'}
                </Button>
              </div>
            </form>
          </Card>
        );
      default:
        return null;
    }
  };

  if (!patient) {
    return (
      <div className="flex justify-center items-center h-full">
        <Spinner size="lg" />
        <p className="ml-4">Loading patient data...</p>
      </div>
    );
  }
  
  const TABS = [
    { id: 'appointments' as PatientDashboardTab, label: 'My Appointments', icon: <CalendarDaysIcon className="w-5 h-5 mr-2" /> },
    { id: 'history' as PatientDashboardTab, label: 'Medical History', icon: <ClipboardDocumentListIcon className="w-5 h-5 mr-2" /> },
    { id: 'profile' as PatientDashboardTab, label: 'Edit Profile', icon: <PencilSquareIcon className="w-5 h-5 mr-2" /> },
  ];

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold text-gray-800 mb-6">Welcome, {patient.name}!</h1>
      
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8" aria-label="Tabs">
            {TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setError(null); setSuccess(null);}}
                className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center
                  ${activeTab === tab.id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
             <button
                onClick={() => { setActiveTab('book'); setError(null); setSuccess(null); }}
                className={`whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center ml-auto
                  ${activeTab === 'book'
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
              >
                <PlusCircleIcon className="w-5 h-5 mr-2" /> Book New Appointment
              </button>
          </nav>
        </div>
      </div>
      
      {renderTabContent()}
    </div>
  );
};

export default PatientDashboard;
