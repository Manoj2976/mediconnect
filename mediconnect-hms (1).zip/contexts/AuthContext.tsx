
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import { UserRole, AppUser, Patient, Doctor, Admin } from '../types';
import { ROUTE_PATHS } from '../constants';
import { useNavigate } from 'react-router-dom';
import * as apiService from '../services/apiService'; // Using * as ... for clarity

interface AuthContextType {
  currentUser: AppUser;
  currentRole: UserRole | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>; // Role parameter removed
  register: (patientData: Omit<Patient, 'id' | 'role' | 'medicalHistory'>) => Promise<void>;
  logout: () => void;
  updateUserProfile: (updatedUser: Partial<Patient | Doctor>) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<AppUser>(null);
  const [currentRole, setCurrentRole] = useState<UserRole | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  const loadUserFromStorage = useCallback(() => {
    try {
      const storedUser = localStorage.getItem('currentUser');
      const storedRole = localStorage.getItem('currentRole');
      if (storedUser && storedRole) {
        setCurrentUser(JSON.parse(storedUser));
        setCurrentRole(storedRole as UserRole);
      }
    } catch (error) {
      console.error("Failed to load user from storage", error);
      localStorage.removeItem('currentUser');
      localStorage.removeItem('currentRole');
    }
    setIsLoading(false);
  }, []);

  useEffect(() => {
    loadUserFromStorage();
  }, [loadUserFromStorage]);

  const updateUserProfile = async (updatedData: Partial<Patient | Doctor>) => {
    if (!currentUser) throw new Error("No user logged in to update.");
    try {
      const updatedUser = await apiService.updateUserProfile(currentUser.id, updatedData);
      setCurrentUser(updatedUser);
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    } catch (error) {
      console.error("Failed to update user profile:", error);
      throw error;
    }
  };

  const login = async (email: string, password: string) => { // Role parameter removed
    setIsLoading(true);
    try {
      const user = await apiService.loginUser(email, password); // Call updated loginUser
      setCurrentUser(user);
      setCurrentRole(user.role);
      localStorage.setItem('currentUser', JSON.stringify(user));
      localStorage.setItem('currentRole', user.role);
      
      switch (user.role) {
        case UserRole.ADMIN:
          navigate(ROUTE_PATHS.ADMIN_DASHBOARD);
          break;
        case UserRole.DOCTOR:
          navigate(ROUTE_PATHS.DOCTOR_DASHBOARD);
          break;
        case UserRole.PATIENT:
          navigate(ROUTE_PATHS.PATIENT_DASHBOARD);
          break;
        default:
          navigate(ROUTE_PATHS.LOGIN);
      }
    } catch (error) {
      console.error("Login failed:", error);
      throw error; // Re-throw to be caught by UI
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (patientData: Omit<Patient, 'id' | 'role' | 'medicalHistory'>) => {
    setIsLoading(true);
    try {
      const newPatient = await apiService.registerPatient(patientData);
      // Optionally log in the user after registration or redirect to login
      // For now, redirect to login page
      alert('Registration successful! Please log in.');
      navigate(ROUTE_PATHS.LOGIN);
    } catch (error) {
      console.error("Registration failed:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentRole(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('currentRole');
    navigate(ROUTE_PATHS.LOGIN);
  };

  return (
    <AuthContext.Provider value={{ currentUser, currentRole, isLoading, login, register, logout, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
