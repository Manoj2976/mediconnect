
import { UserRole, Patient, Doctor, Admin, Appointment, AvailabilitySlot, AppUser, MedicalRecord } from '../types';

// In-memory data store
let users: Array<Patient | Doctor | Admin> = [
  { id: 'admin1', email: 'admin@hospital.com', password: 'password', role: UserRole.ADMIN, name: 'Admin User' },
  { id: 'doc1', email: 'doctor1@hospital.com', password: 'password', role: UserRole.DOCTOR, name: 'Dr. Alice Smith', specialization: 'Cardiology', phone: '123-456-7890', availability: [
    { dayOfWeek: 'Monday', startTime: '09:00', endTime: '17:00' },
    { dayOfWeek: 'Wednesday', startTime: '10:00', endTime: '15:00' },
  ]},
  { id: 'doc2', email: 'doctor2@hospital.com', password: 'password', role: UserRole.DOCTOR, name: 'Dr. Bob Johnson', specialization: 'Pediatrics', phone: '987-654-3210', availability: [
    { dayOfWeek: 'Tuesday', startTime: '08:00', endTime: '16:00' },
    { dayOfWeek: 'Thursday', startTime: '13:00', endTime: '18:00' },
  ]},
  { id: 'patient1', email: 'patient1@example.com', password: 'password', role: UserRole.PATIENT, name: 'John Doe', medicalHistory: [], dob: '1990-01-01', phone: '555-0101', address: '123 Main St' },
];

let appointments: Appointment[] = [
    { id: 'apt1', patientId: 'patient1', patientName: 'John Doe', doctorId: 'doc1', doctorName: 'Dr. Alice Smith', date: '2024-07-20', time: '10:00', reason: 'Chest pain', status: 'booked' },
    { id: 'apt2', patientId: 'patient1', patientName: 'John Doe', doctorId: 'doc2', doctorName: 'Dr. Bob Johnson', date: '2024-07-22', time: '14:00', reason: 'Child checkup', status: 'completed' },
];

let medicalRecords: MedicalRecord[] = [
  { id: 'rec1', appointmentId: 'apt2', date: '2024-07-22', notes: 'Routine checkup, child is healthy.', diagnosis: 'Healthy', prescription: 'N/A' },
];


// --- Auth ---
export const loginUser = (email: string, password: string): Promise<AppUser> => { // role parameter removed
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const user = users.find(u => u.email === email && u.password === password);
      if (user) {
        resolve(user);
      } else {
        reject(new Error('Invalid email or password.'));
      }
    }, 500);
  });
};

export const registerPatient = (patientData: Omit<Patient, 'id' | 'role' | 'medicalHistory'>): Promise<Patient> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (users.find(u => u.email === patientData.email)) {
        reject(new Error('Email already exists.'));
        return;
      }
      const newPatient: Patient = {
        ...patientData,
        id: `patient${users.length + 1}`,
        role: UserRole.PATIENT,
        medicalHistory: [],
      };
      users.push(newPatient);
      resolve(newPatient);
    }, 500);
  });
};

export const updateUserProfile = (userId: string, updatedData: Partial<Patient | Doctor>): Promise<AppUser> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const userIndex = users.findIndex(u => u.id === userId);
      if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...updatedData } as AppUser;
        resolve(users[userIndex]);
      } else {
        reject(new Error('User not found.'));
      }
    }, 300);
  });
};

// --- Patient Specific ---
export const getPatientAppointments = (patientId: string): Promise<Appointment[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(appointments.filter(apt => apt.patientId === patientId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }, 300);
  });
};

export const getPatientMedicalRecords = (patientId: string): Promise<MedicalRecord[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      // Find appointments for the patient, then collect medical records related to those appointments
      const patientAptIds = appointments.filter(apt => apt.patientId === patientId).map(apt => apt.id);
      resolve(medicalRecords.filter(rec => patientAptIds.includes(rec.appointmentId)).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }, 300);
  });
};

export const bookAppointment = (appointmentData: Omit<Appointment, 'id' | 'patientName' | 'doctorName' | 'status'>): Promise<Appointment> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const patient = users.find(u => u.id === appointmentData.patientId && u.role === UserRole.PATIENT) as Patient;
      const doctor = users.find(u => u.id === appointmentData.doctorId && u.role === UserRole.DOCTOR) as Doctor;

      if (!patient || !doctor) {
        reject(new Error("Patient or Doctor not found."));
        return;
      }

      // Check for conflicts (simplified)
      const conflict = appointments.find(apt => apt.doctorId === appointmentData.doctorId && apt.date === appointmentData.date && apt.time === appointmentData.time && apt.status === 'booked');
      if (conflict) {
        reject(new Error("Time slot already booked."));
        return;
      }

      const newAppointment: Appointment = {
        ...appointmentData,
        id: `apt${appointments.length + 1}`,
        patientName: patient.name,
        doctorName: doctor.name,
        status: 'booked',
      };
      appointments.push(newAppointment);
      resolve(newAppointment);
    }, 500);
  });
};

export const cancelAppointment = (appointmentId: string): Promise<Appointment> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const aptIndex = appointments.findIndex(a => a.id === appointmentId);
      if (aptIndex !== -1) {
        appointments[aptIndex].status = 'cancelled';
        resolve(appointments[aptIndex]);
      } else {
        reject(new Error("Appointment not found."));
      }
    }, 300);
  });
};


// --- Doctor Specific ---
export const getDoctorAppointments = (doctorId: string): Promise<Appointment[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(appointments.filter(apt => apt.doctorId === doctorId).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }, 300);
  });
};

export const getDoctorAvailability = (doctorId: string): Promise<AvailabilitySlot[]> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            const doctor = users.find(u => u.id === doctorId && u.role === UserRole.DOCTOR) as Doctor | undefined;
            if (doctor && doctor.availability) {
                resolve(doctor.availability);
            } else if (doctor) {
                resolve([]); // Doctor exists but no availability set
            }
            else {
                reject(new Error("Doctor not found."));
            }
        }, 300);
    });
};

export const updateDoctorAvailability = (doctorId: string, availability: AvailabilitySlot[]): Promise<Doctor> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const docIndex = users.findIndex(u => u.id === doctorId && u.role === UserRole.DOCTOR);
      if (docIndex !== -1) {
        (users[docIndex] as Doctor).availability = availability;
        resolve(users[docIndex] as Doctor);
      } else {
        reject(new Error("Doctor not found."));
      }
    }, 500);
  });
};

export const addMedicalRecord = (recordData: Omit<MedicalRecord, 'id'>) : Promise<MedicalRecord> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const appointment = appointments.find(apt => apt.id === recordData.appointmentId);
      if(!appointment) {
        reject(new Error("Associated appointment not found."));
        return;
      }
      if(appointment.status !== 'completed'){
        // Logic: can only add record for completed appointments, or update status here
        appointment.status = 'completed'; // Mark as completed if adding record
      }

      const newRecord: MedicalRecord = {
        ...recordData,
        id: `rec${medicalRecords.length + 1}`,
      };
      medicalRecords.push(newRecord);
      resolve(newRecord);
    }, 500);
  });
}

// --- Admin Specific ---
export const getAllDoctors = (): Promise<Doctor[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(users.filter(u => u.role === UserRole.DOCTOR) as Doctor[]);
    }, 300);
  });
};

export const addDoctor = (doctorData: Omit<Doctor, 'id' | 'role' | 'availability'>): Promise<Doctor> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (users.find(u => u.email === doctorData.email)) {
        reject(new Error('Email already exists.'));
        return;
      }
      const newDoctor: Doctor = {
        ...doctorData,
        id: `doc${users.length + 1}`,
        role: UserRole.DOCTOR,
        availability: [],
      };
      users.push(newDoctor);
      resolve(newDoctor);
    }, 500);
  });
};

export const updateDoctor = (doctorId: string, doctorData: Partial<Omit<Doctor, 'id' | 'role'>>): Promise<Doctor> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const docIndex = users.findIndex(u => u.id === doctorId && u.role === UserRole.DOCTOR);
      if (docIndex !== -1) {
        users[docIndex] = { ...users[docIndex], ...doctorData } as Doctor;
        resolve(users[docIndex] as Doctor);
      } else {
        reject(new Error("Doctor not found."));
      }
    }, 500);
  });
};

export const deleteDoctor = (doctorId: string): Promise<void> => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      const initialLength = users.length;
      users = users.filter(u => u.id !== doctorId || u.role !== UserRole.DOCTOR);
      if (users.length < initialLength) {
        // Also remove appointments associated with this doctor or reassign them (simplified: just remove)
        appointments = appointments.filter(apt => apt.doctorId !== doctorId);
        resolve();
      } else {
        reject(new Error("Doctor not found or could not be deleted."));
      }
    }, 500);
  });
};

export const getAllAppointments = (): Promise<Appointment[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([...appointments].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    }, 300);
  });
};

export const getAllPatients = (): Promise<Patient[]> => {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(users.filter(u => u.role === UserRole.PATIENT) as Patient[]);
    }, 300);
  });
};
